from django.shortcuts import render
from django.contrib.auth.decorators import login_required

# Create your views here.
@login_required
def index(request):
    return render(request, 'index.html')

# Category
def listCategory(request):
    return render(request, 'staff/category/list.html')

def createCategory(request):
    return render(request, 'staff/category/form.html')

def updateCategory(request, pk):
    return render(request, 'staff/category/form.html')

# Product
def listProduct(request):
    return render(request, 'staff/product/list.html')

def createProduct(request):
    return render(request, 'staff/product/form.html')

def updateProduct(request, pk):
    return render(request, 'staff/product/form.html')

# Order
def listOrder(request):
    return render(request, 'staff/order/list.html')

def viewOrder(request, pk):
    return render(request, 'staff/order/view_detail.html')
