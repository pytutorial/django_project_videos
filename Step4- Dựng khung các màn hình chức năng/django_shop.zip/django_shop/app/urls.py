#app/urls.py
from django.urls import path
from .views import *

urlpatterns = [
    path('', index, name='home'),
    
    # Category
    path('staff', listCategory),
    path('staff/create-category', createCategory),
    path('staff/update-category/<pk>', updateCategory),

    # Product
    path('staff/list-product', listProduct),
    path('staff/create-product', createProduct),
    path('staff/update-product/<pk>', updateProduct),

    # Order
    path('staff/list-order', listOrder),
    path('staff/view-order/<pk>', viewOrder),
]