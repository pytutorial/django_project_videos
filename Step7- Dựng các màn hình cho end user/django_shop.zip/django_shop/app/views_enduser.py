#app/views_enduser.py
from django.shortcuts import render, get_object_or_404
from .models import *

def index(request):
    productList = Product.objects.all()
    context = {'productList': productList}
    return render(request, 'enduser/index.html', context)

def viewProduct(request, pk):
    product = get_object_or_404(Product, pk=pk)
    context = {'product': product}
    return render(request, 'enduser/view_product.html', context)

def orderProduct(request, pk):
    return render(request, 'enduser/order_product.html')

def thankYou(request):
    return render(request, 'enduser/thank_you.html')